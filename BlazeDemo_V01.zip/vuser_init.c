vuser_init()
{
	web_reg_save_param("C_ItemCategory",
		"LB=byCat('",
		"RB=')",
		"NotFound=WARNING",
		"Search=Body",
		"ORD=ALL",
		LAST);
	
	lr_start_transaction("Blazedemo_01_Launch");

	web_url("demoblaze.com", 
		"URL=http://demoblaze.com/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://demoblaze.com/imgs/front.jpg", "Referer=https://demoblaze.com/", ENDITEM, 
		"Url=https://demoblaze.com/css/fonts/Lato-Regular.woff2", "Referer=https://demoblaze.com/css/latofonts.css", ENDITEM, 
		"Url=https://demoblaze.com/config.json", "Referer=https://demoblaze.com/", ENDITEM, 
		"Url=https://hls.demoblaze.com/index.m3u8", "Referer=https://demoblaze.com/", ENDITEM, 
		"Url=https://api.demoblaze.com/entries", "Referer=https://demoblaze.com/", ENDITEM, 
		"Url=https://hls.demoblaze.com/about_demo_hls_600k.m3u8", "Referer=https://demoblaze.com/", ENDITEM, 
		"Url=https://demoblaze.com/imgs/galaxy_s6.jpg", "Referer=https://demoblaze.com/", ENDITEM, 
		"Url=https://demoblaze.com/imgs/Lumia_1520.jpg", "Referer=https://demoblaze.com/", ENDITEM, 
		"Url=https://demoblaze.com/imgs/Nexus_6.jpg", "Referer=https://demoblaze.com/", ENDITEM, 
		"Url=https://demoblaze.com/imgs/iphone_6.jpg", "Referer=https://demoblaze.com/", ENDITEM, 
		"Url=https://demoblaze.com/imgs/xperia_z5.jpg", "Referer=https://demoblaze.com/", ENDITEM, 
		"Url=https://demoblaze.com/imgs/HTC_M9.jpg", "Referer=https://demoblaze.com/", ENDITEM, 
		"Url=https://demoblaze.com/imgs/sony_vaio_5.jpg", "Referer=https://demoblaze.com/", ENDITEM, 
		"Url=https://hls.demoblaze.com/about_demo_hls_600k00000.ts", "Referer=https://demoblaze.com/", ENDITEM, 
		LAST);
	
	if(atoi(lr_eval_string("{C_ItemCategory_count}"))>0)
	{
		lr_end_transaction("Blazedemo_01_Launch", LR_AUTO);

	}
	else
	{
		lr_error_message("Launch failed for User %s , Iteration %s , LG %s, Vuser %s",lr_eval_string("{P_UName}"),lr_eval_string("{P_Ite}"),lr_eval_string("{P_LG}"),lr_eval_string("{P_Vuser}"));
		lr_end_transaction("Blazedemo_01_Launch", LR_FAIL);
		lr_exit(LR_EXIT_ITERATION_AND_CONTINUE,LR_FAIL);

	}

	web_custom_request("login", 
		"URL=https://api.demoblaze.com/login", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demoblaze.com/", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);
	
	//S2FuY2hhbjE2NDYxMjI=
	
	web_reg_save_param("C_AuthToken",
		"LB=Auth_token: ",
		"RB=\"",
		"NotFound=WARNING",
		"Search=Body",
		LAST);
	
	web_reg_find("Text=Auth_token","SaveCount=TextCheck",LAST);
	
	//Password is base64 encrypted, in case of multiple username and pwd
	//js code needs to be written to encrypt, need time to do the same
	
	lr_start_transaction("Blazedemo_02_Login");

	web_custom_request("login_2", 
		"URL=https://api.demoblaze.com/login", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demoblaze.com/", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"username\":\"{P_UName}\",\"password\":\"S2FuY2hhbkAxMjM=\"}", 
		LAST);

	web_add_cookie("tokenp_={C_AuthToken}; DOMAIN=demoblaze.com");

	web_url("demoblaze.com_2", 
		"URL=https://demoblaze.com/", 
		"Resource=0", 
		"Referer=https://demoblaze.com/", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/imgs/front.jpg", ENDITEM, 
		"Url=/config.json", ENDITEM, 
		"Url=https://api.demoblaze.com/entries", ENDITEM, 
		"Url=/imgs/galaxy_s6.jpg", ENDITEM, 
		"Url=/imgs/Lumia_1520.jpg", ENDITEM, 
		"Url=/imgs/Nexus_6.jpg", ENDITEM, 
		"Url=/imgs/iphone_6.jpg", ENDITEM, 
		"Url=/imgs/xperia_z5.jpg", ENDITEM, 
		"Url=/imgs/HTC_M9.jpg", ENDITEM, 
		"Url=/imgs/sony_vaio_5.jpg", ENDITEM, 
		"Url=/favicon.ico", ENDITEM, 
		"Url=/imgs/macbook_air.jpg", ENDITEM, 
		"Url=/imgs/dell.jpg", ENDITEM, 
		LAST);

	web_custom_request("check", 
		"URL=https://api.demoblaze.com/check", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demoblaze.com/", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("check_2", 
		"URL=https://api.demoblaze.com/check", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demoblaze.com/", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"token\":\"{C_AuthToken}\"}", 
		LAST);
	
	if(atoi(lr_eval_string("{TextCheck}"))>0)
	{
		lr_end_transaction("Blazedemo_02_Login", LR_AUTO);

	}
	else
	{
		lr_error_message("Login failed for User %s , Iteration %s , LG %s, Vuser %s",lr_eval_string("{P_UName}"),lr_eval_string("{P_Ite}"),lr_eval_string("{P_LG}"),lr_eval_string("{P_Vuser}"));
		lr_end_transaction("Blazedemo_02_Login", LR_FAIL);
		lr_exit(LR_EXIT_ITERATION_AND_CONTINUE,LR_FAIL);

	}
	
	return 0;
}
