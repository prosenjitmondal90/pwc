Action()
{	
	lr_save_string(lr_paramarr_random("C_ItemCategory"),"C_Category_To_Click");

	web_custom_request("bycat", 
		"URL=https://api.demoblaze.com/bycat", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demoblaze.com/", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);
	
	//9
	
	web_reg_save_param("C_ProdId",
		"LB=\"id\":",
		"RB=,",
		"NotFound=WARNING",
		"Search=Body",
		"ORD=ALL",
		LAST);

	web_custom_request("bycat_2", 
		"URL=https://api.demoblaze.com/bycat", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demoblaze.com/", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"cat\":\"{C_Category_To_Click}\"}", 
		LAST);
	
	lr_save_string(lr_paramarr_random("C_ProdId"),"C_ProdId_To_Click");

	web_url("prod.html", 
		"URL=https://demoblaze.com/prod.html?idp_={C_ProdId_To_Click}", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demoblaze.com/", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/css/fonts/Lato-Regular.woff2", "Referer=https://demoblaze.com/css/latofonts.css", ENDITEM, 
		"Url=/imgs/front.jpg", "Referer=https://demoblaze.com/prod.html?idp_={C_ProdId_To_Click}", ENDITEM, 
		"Url=/config.json", "Referer=https://demoblaze.com/prod.html?idp_={C_ProdId_To_Click}", ENDITEM, 
		LAST);

	web_custom_request("check_3", 
		"URL=https://api.demoblaze.com/check", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demoblaze.com/", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("view", 
		"URL=https://api.demoblaze.com/view", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demoblaze.com/", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("check_4", 
		"URL=https://api.demoblaze.com/check", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demoblaze.com/", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"token\":\"{C_AuthToken}\"}", 
		LAST);

	web_custom_request("view_2", 
		"URL=https://api.demoblaze.com/view", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demoblaze.com/", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"id\":\"{C_ProdId_To_Click}\"}", 
		EXTRARES, 
		"Url=https://demoblaze.com/imgs/sony_vaio_5.jpg", "Referer=https://demoblaze.com/prod.html?idp_={C_ProdId_To_Click}", ENDITEM, 
		LAST);
	
	//add to cart 1

	web_custom_request("addtocart", 
		"URL=https://api.demoblaze.com/addtocart", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demoblaze.com/", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);
	
	//need to generate uuid, custom c or js cde needs to be written

	web_custom_request("addtocart_2", 
		"URL=https://api.demoblaze.com/addtocart", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demoblaze.com/", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"id\":\"be4dff66-a222-c927-7a94-bd2369909409\",\"cookie\":\"{C_AuthToken}\",\"prod_id\":{C_ProdId_To_Click},\"flag\":true}", 
		LAST);
	
	//add to cart 2

	web_custom_request("addtocart_3", 
		"URL=https://api.demoblaze.com/addtocart", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demoblaze.com/", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("addtocart_4", 
		"URL=https://api.demoblaze.com/addtocart", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demoblaze.com/", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"id\":\"b5e878e4-8a0f-a8a1-ec03-00acba2b0e7c\",\"cookie\":\"{C_AuthToken}\",\"prod_id\":{C_ProdId_To_Click},\"flag\":true}", 
		LAST);
	
	//view cart

	web_url("cart.html", 
		"URL=https://demoblaze.com/cart.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demoblaze.com/prod.html?idp_={C_ProdId_To_Click}", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/imgs/front.jpg", ENDITEM, 
		"Url=/css/fonts/Lato-Regular.woff2", "Referer=https://demoblaze.com/css/latofonts.css", ENDITEM, 
		"Url=/config.json", ENDITEM, 
		"Url=/imgs/sony_vaio_5.jpg", ENDITEM, 
		"Url=/favicon.ico", ENDITEM, 
		LAST);

	web_custom_request("check_5", 
		"URL=https://api.demoblaze.com/check", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demoblaze.com/", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("viewcart", 
		"URL=https://api.demoblaze.com/viewcart", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demoblaze.com/", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("check_6", 
		"URL=https://api.demoblaze.com/check", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demoblaze.com/", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"token\":\"{C_AuthToken}\"}", 
		LAST);

	web_custom_request("viewcart_2", 
		"URL=https://api.demoblaze.com/viewcart", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demoblaze.com/", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"cookie\":\"{C_AuthToken}\",\"flag\":true}", 
		LAST);

	web_custom_request("view_3", 
		"URL=https://api.demoblaze.com/view", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demoblaze.com/", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("view_4", 
		"URL=https://api.demoblaze.com/view", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demoblaze.com/", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("view_5", 
		"URL=https://api.demoblaze.com/view", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demoblaze.com/", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"id\":{C_ProdId_To_Click}}", 
		LAST);

	web_custom_request("view_6", 
		"URL=https://api.demoblaze.com/view", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demoblaze.com/", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"id\":{C_ProdId_To_Click}}", 
		LAST);
	
	//delete from cart

	web_custom_request("deleteitem", 
		"URL=https://api.demoblaze.com/deleteitem", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demoblaze.com/", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		LAST);
	
	//first uuid generated to be stored and passed here to delete the same product

	web_custom_request("deleteitem_2", 
		"URL=https://api.demoblaze.com/deleteitem", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demoblaze.com/", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"id\":\"be4dff66-a222-c927-7a94-bd2369909409\"}", 
		LAST);

	web_url("cart.html_2", 
		"URL=https://demoblaze.com/cart.html", 
		"Resource=0", 
		"Referer=https://demoblaze.com/cart.html", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/node_modules/bootstrap/dist/css/bootstrap.min.css", ENDITEM, 
		"Url=/node_modules/bootstrap-sweetalert/dist/sweetalert.css", ENDITEM, 
		"Url=/node_modules/video.js/dist/video-js.min.css", ENDITEM, 
		"Url=/css/latofonts.css", ENDITEM, 
		"Url=/css/latostyle.css", ENDITEM, 
		"Url=/node_modules/jquery/dist/jquery.min.js", ENDITEM, 
		"Url=/node_modules/videojs-contrib-hls/dist/videojs-contrib-hls.min.js", ENDITEM, 
		"Url=/node_modules/video.js/dist/video.min.js", ENDITEM, 
		"Url=/node_modules/tether/dist/js/tether.min.js", ENDITEM, 
		"Url=/node_modules/bootstrap/dist/js/bootstrap.min.js", ENDITEM, 
		"Url=/node_modules/bootstrap-sweetalert/dist/sweetalert.min.js", ENDITEM, 
		"Url=/js/cart.js", ENDITEM, 
		"Url=/imgs/front.jpg", ENDITEM, 
		"Url=/bm.png", ENDITEM, 
		"Url=/config.json", ENDITEM, 
		"Url=/imgs/sony_vaio_5.jpg", ENDITEM, 
		LAST);

	web_custom_request("check_7", 
		"URL=https://api.demoblaze.com/check", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demoblaze.com/", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("viewcart_3", 
		"URL=https://api.demoblaze.com/viewcart", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demoblaze.com/", 
		"Snapshot=t31.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("viewcart_4", 
		"URL=https://api.demoblaze.com/viewcart", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demoblaze.com/", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"cookie\":\"{C_AuthToken}\",\"flag\":true}", 
		LAST);

	web_custom_request("check_8", 
		"URL=https://api.demoblaze.com/check", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demoblaze.com/", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"token\":\"{C_AuthToken}\"}", 
		LAST);

	web_custom_request("view_7", 
		"URL=https://api.demoblaze.com/view", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demoblaze.com/", 
		"Snapshot=t34.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("view_8", 
		"URL=https://api.demoblaze.com/view", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demoblaze.com/", 
		"Snapshot=t35.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"id\":{C_ProdId_To_Click}}", 
		LAST);

	web_custom_request("deletecart", 
		"URL=https://api.demoblaze.com/deletecart", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demoblaze.com/", 
		"Snapshot=t37.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("deletecart_2", 
		"URL=https://api.demoblaze.com/deletecart", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demoblaze.com/", 
		"Snapshot=t38.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"cookie\":\"{P_UName}\"}", 
		LAST);

	web_add_cookie("COMPASS=bigtop-sync=CosBAAlriVccBCHCBvfFw75r58kepyxr1Qr-KqNyHjtUm_uSnvne1I3ZVbhxDMlqETj7MAA83hjcT75l7BTl6IjLFSY-INvoZmYfl8rdPRXgZaI_kiWE-p4mlqDmJm31-jJK9rgc85JfF10MscxMYpTBxGulcAwYOocySIAReEYz1gzVmV15yAQjPhQFXBC98tKQBhqdAQAJa4lXsYv19b5EoqJFYgTwWPNgM7of4qdYaCfb59EA89dcbVjPFS87FerxleOz1WXm_98_Uzi0ODLgO44ugsWnkGmsrK-cz_XeoNz6JxQ5Lmnt1YvOki-ATEvWeOuTHq0RwEQZUMGNHHWMBlEKXYPUmtBJ40nSKyFLqz8LQtO9ap6OpH5Ofe-J92uCtPBMyVDfeurgBKvXMYWa6Ig; DOMAIN=mail.google.com");

	web_add_cookie("ANID=AHWqTUlaTHJaSUjFjrt9VhawsOyc-xZnj9zLzk02JhKSf62WdpkTo2GGSeYnaq17; DOMAIN=mail.google.com");

	web_add_cookie("HSID=AQvZDfG62aViePVcD; DOMAIN=mail.google.com");

	web_add_cookie("SSID=AjUmeHyZaJ3rUXve0; DOMAIN=mail.google.com");

	web_add_cookie("APISID=kBTZqZajVimBZsFY/AjCHYz9GlFaQPypTi; DOMAIN=mail.google.com");

	web_add_cookie("SAPISID=4yctiA69UpaqzhFB/AQ3uBmCYyuvmg_O1r; DOMAIN=mail.google.com");

	web_add_cookie("__Secure-1PAPISID=4yctiA69UpaqzhFB/AQ3uBmCYyuvmg_O1r; DOMAIN=mail.google.com");

	web_add_cookie("__Secure-3PAPISID=4yctiA69UpaqzhFB/AQ3uBmCYyuvmg_O1r; DOMAIN=mail.google.com");

	web_add_cookie("OGPC=19025813-1:19025836-2:19027511-1:; DOMAIN=mail.google.com");

	web_add_cookie("OGP=-19027511:; DOMAIN=mail.google.com");

	web_add_cookie("SEARCH_SAMESITE=CgQI1pQB; DOMAIN=mail.google.com");

	web_add_cookie("__Host-GMAIL_SCH_GMN=1; DOMAIN=mail.google.com");

	web_add_cookie("__Host-GMAIL_SCH_GMS=1; DOMAIN=mail.google.com");

	web_add_cookie("__Host-GMAIL_SCH_GML=1; DOMAIN=mail.google.com");

	web_add_cookie("SID=GwgOXHGSrOIsrO77mOFgpUgZ8jAQsEPjuwo7uPKqBpY-DpsQo9zMrYfOaYm1hJxYTVsaSA.; DOMAIN=mail.google.com");

	web_add_cookie("__Secure-1PSID=GwgOXHGSrOIsrO77mOFgpUgZ8jAQsEPjuwo7uPKqBpY-DpsQu9n6K6_iCbERTTtd_bZO1A.; DOMAIN=mail.google.com");

	web_add_cookie("__Secure-3PSID=GwgOXHGSrOIsrO77mOFgpUgZ8jAQsEPjuwo7uPKqBpY-DpsQigNT9pCaRI4dvHF3OM4fmQ.; DOMAIN=mail.google.com");

	web_add_cookie("OSID=GwgOXBstdh0AiSmjyU6C2FkTD5HGjspU1JYs6MQEbtTR-LHbmw2T95IJD-KFDnSjomYFyA.; DOMAIN=mail.google.com");

	web_add_cookie("__Secure-OSID=GwgOXBstdh0AiSmjyU6C2FkTD5HGjspU1JYs6MQEbtTR-LHbLmnP8YwT6GDpaGwhO-zVRQ.; DOMAIN=mail.google.com");

	web_add_cookie("__Secure-1PSIDCC=AJi4QfH_iisjTq3TSY2d9MzdsS2LS038_tw62r0YyCteau4voHIPPM7QX42aiXSfCA5NLauxOg; DOMAIN=mail.google.com");

	web_add_cookie("NID=511=e1FdSvhNPdAuYL5sujWBC5SHZYWLTa1GGphz-Whyt9ft7lWZ0aYRAVSNMZ-1Pcpd199RU-5N9x73Az1q6osIT5E3rpr5burUZuDgz79hk9PEgFmDKcpetOY6HJp9NYiLn2asKY864VSjQUpgpFEuUZnY58rR5J4ZJ1Zi9H9MFMwMa8MfuqsypO8ruw0UtIaw_askRi6Py9r9j4KZLy-UkPZEOpMOIesdgwDL0mAYCpdsG0bnxgDxDV-Mk5TbsFgHErQsuWTg2urat9xgizhnyHEUdsekpLi60yemI1Ps_9jM3Rv3hdPDt8sC_f3ool0y6G3hPLBw-D_XPCWrejwAXfAeIjCZ5G0Rz7ZvI2pkdew; DOMAIN=mail.google.com");

	web_add_cookie("1P_JAR=2022-02-22-09; DOMAIN=mail.google.com");

	web_add_cookie("__Host-GMAIL_SCH=nsl; DOMAIN=mail.google.com");

	web_add_cookie("SIDCC=AJi4QfGRIWnmkZ8QGKuw-0cWt4zVmXXzxGfe4zYbm3Q1fzxocFSczluiq6dN6Iqk0sRmdpPUoRfu; DOMAIN=mail.google.com");

	web_add_cookie("__Secure-3PSIDCC=AJi4QfERtqe-Qg0suwwe6yhec1MSoVyW7CiSRmYZO9vh4-UlgrhkdgvCy01GpdxLY2Xhxjkj4Qe7; DOMAIN=mail.google.com");

	web_custom_request("deletecart_3", 
		"URL=https://api.demoblaze.com/deletecart", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demoblaze.com/", 
		"Snapshot=t40.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("deletecart_4", 
		"URL=https://api.demoblaze.com/deletecart", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demoblaze.com/", 
		"Snapshot=t41.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"cookie\":\"{P_UName}\"}", 
		LAST);

	web_add_cookie("SIDCC=AJi4QfEI9Xv-mIfCyEq4YRjsCoWLZUdG05zPGUiBauUOk5XQjtD8PtAuS2s5yFDMBG8lPzXBVYzf; DOMAIN=mail.google.com");

	web_add_cookie("__Secure-3PSIDCC=AJi4QfGfUSn2WuCIxX358lZQ95E60zwgCVnImcEv7eqFw08j5bqZtYYC2NJawdsbxJ2EOANgOFzr; DOMAIN=mail.google.com");

	web_url("index.html", 
		"URL=https://demoblaze.com/index.html", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demoblaze.com/cart.html", 
		"Snapshot=t43.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/imgs/front.jpg", ENDITEM, 
		"Url=/css/fonts/Lato-Regular.woff2", "Referer=https://demoblaze.com/css/latofonts.css", ENDITEM, 
		"Url=/config.json", ENDITEM, 
		"Url=/imgs/sony_vaio_5.jpg", ENDITEM, 
		"Url=/imgs/Lumia_1520.jpg", ENDITEM, 
		"Url=/imgs/galaxy_s6.jpg", ENDITEM, 
		"Url=/imgs/Nexus_6.jpg", ENDITEM, 
		"Url=/imgs/iphone_6.jpg", ENDITEM, 
		"Url=/imgs/xperia_z5.jpg", ENDITEM, 
		"Url=/imgs/HTC_M9.jpg", ENDITEM, 
		LAST);

	web_custom_request("check_9", 
		"URL=https://api.demoblaze.com/check", 
		"Method=OPTIONS", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://demoblaze.com/", 
		"Snapshot=t44.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("check_10", 
		"URL=https://api.demoblaze.com/check", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://demoblaze.com/", 
		"Snapshot=t45.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"token\":\"{C_AuthToken}\"}", 
		LAST);

	web_url("index.html_2", 
		"URL=https://demoblaze.com/index.html", 
		"Resource=0", 
		"Referer=https://demoblaze.com/index.html", 
		"Snapshot=t46.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/imgs/front.jpg", ENDITEM, 
		"Url=/config.json", ENDITEM, 
		"Url=/imgs/galaxy_s6.jpg", ENDITEM, 
		"Url=/imgs/Lumia_1520.jpg", ENDITEM, 
		"Url=/imgs/Nexus_6.jpg", ENDITEM, 
		"Url=/imgs/iphone_6.jpg", ENDITEM, 
		"Url=/imgs/xperia_z5.jpg", ENDITEM, 
		"Url=/imgs/HTC_M9.jpg", ENDITEM, 
		"Url=/imgs/sony_vaio_5.jpg", ENDITEM, 
		LAST);

	return 0;
}